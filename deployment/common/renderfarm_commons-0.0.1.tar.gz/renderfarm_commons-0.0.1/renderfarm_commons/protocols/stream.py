# coding: utf-8

# Copyright Luna Technology 2014
# Matthieu Riviere <mriviere@luna-technology.com>

"""Helpers functions to serialize and deserialize protobuf messages in a streaming context"""

import struct
import logging


def pack_message(message):
    s = message.SerializeToString()
    packed_len = struct.pack('>L', len(s))
    return packed_len + s


def extract_message(data_buf, msgtype):
    if len(data_buf) > 4:
        len_buf = data_buf[0:4]
        msg_len = struct.unpack('>L', len_buf)[0]

        if len(data_buf) >= 4 + msg_len:
            msg_buf = data_buf[4:4+msg_len]
            data_buf = data_buf[4+msg_len:]
            try:
                ret = msgtype()
                ret.ParseFromString(msg_buf)
                return data_buf, ret
            except Exception:
                logging.exception('Could not decode message. Dropping it')
                return data_buf, None

    # If we haven't found anything, return the initial buffer, and None as the message
    return data_buf, None