# coding: utf-8

# Copyright Luna Technology 2014
# Matthieu Riviere <mriviere@luna-technology.com>

import unittest
import random
import jobsubmit_pb2
import stream
import luna_commons
from nose.plugins.attrib import attr


@attr(cat='unit')
class TestStreamUtils(unittest.TestCase):
    def gen_random_message(self):
        msg = jobsubmit_pb2.JobResultsResponse()
        msg.result = jobsubmit_pb2.OK
        d = msg.data
        d.return_code = random.randint(0, 100)
        d.stdout = luna_commons.random_num_string()
        d.stderr = luna_commons.random_num_string()

        for i in range(random.randint(0, 100)):
            f = d.output_files.add()
            f.path = "/tmp/test/" + luna_commons.random_num_string()
            f.sha256 = luna_commons.random_num_string()

        return msg

    def assertEqualMessages(self, msg1, msg2):
        self.assertIsNotNone(msg1)
        self.assertIsNotNone(msg2)

        self.assertEqual(msg1.result, msg2.result)

        data1 = msg1.data
        data2 = msg2.data
        self.assertEqual(data1.return_code, data2.return_code)
        self.assertEqual(data1.stdout, data2.stdout)
        self.assertEqual(data1.stderr, data2.stderr)
        self.assertEqual(len(data1.output_files), len(data2.output_files))

        for i in range(len(data1.output_files)):
            self.assertEqual(data1.output_files[i].path, data2.output_files[i].path)
            self.assertEqual(data1.output_files[i].sha256, data2.output_files[i].sha256)

    def test_transmit_a_message(self):
        input_message = self.gen_random_message()
        transmit_message = stream.pack_message(input_message)
        data_buf, output_message = stream.extract_message(transmit_message, jobsubmit_pb2.JobResultsResponse)

        self.assertEqualMessages(input_message, output_message)

    def test_transmit_many_messages(self):
        # Generate some inputs
        input_messages = [self.gen_random_message() for _ in range(random.randint(0, 100))]

        # Sends them out
        data_buf = ''
        for input_message in input_messages:
            data_buf += stream.pack_message(input_message)

        # Read back all messages from the buffer
        output_messages = []
        while len(data_buf) > 0:
            data_buf, output_message = stream.extract_message(data_buf, jobsubmit_pb2.JobResultsResponse)
            output_messages.append(output_message)

        self.assertEqual(len(input_messages), len(output_messages))
        for i in range(len(input_messages)):
            self.assertEqualMessages(input_messages[i], output_messages[i])

    def test_partial_reading(self):
        input_message = self.gen_random_message()

        data_buf = stream.pack_message(input_message)
        l = len(data_buf)

        # Check that reads of the incomplete buffer yield nothing
        for i in range(l-1):
            partial_buf = data_buf[0:i]
            new_data_buf, output_message = stream.extract_message(partial_buf, jobsubmit_pb2.JobResultsResponse)
            self.assertEqual(new_data_buf, partial_buf)
            self.assertIsNone(output_message)

        new_data_buf, output_message = stream.extract_message(data_buf, jobsubmit_pb2.JobResultsResponse)

        self.assertEqual(len(new_data_buf), 0)
        self.assertEqualMessages(input_message, output_message)


if __name__ == '__main__':
    unittest.main()