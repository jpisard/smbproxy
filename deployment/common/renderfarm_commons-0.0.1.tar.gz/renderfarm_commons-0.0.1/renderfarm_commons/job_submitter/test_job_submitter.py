# coding: utf-8

# Copyright Luna Technology 2014
# Matthieu Riviere <mriviere@luna-technology.com>

"""These are tests for the renderfarm_commons.job_submitter.job_submitter class.
These tests are designed to run against a real cluster. Don't run on a production one."""

import unittest
import job_submitter
from luna_commons import create_dir, random_num_string
import shutil
import random
import os
from nose.plugins.attrib import attr

from renderfarm_commons.cache_client.filecache_client3 import CacheClient3

run_job_cmd = job_submitter.run_linux_job_and_wait_for_results
BASE_TESTS_DIR = 'job_submitter_tests'


@attr(cat='integration')
class JobSubmitterTests(unittest.TestCase):

    def setUp(self):
        create_dir(BASE_TESTS_DIR)

    def tearDown(self):
        try:
            shutil.rmtree(BASE_TESTS_DIR)
        except:
            pass

    def test_full_job(self):
        dir_id = 'test_full_job' + str(random.randint(0, 999999))
        cmd = 'ping -c 5 google.fr'
        stdin = ''
        env = {}
        output_files = []
        input_files = []

        result = run_job_cmd(
            dir_id=dir_id,
            cmd=cmd,
            stdin=stdin,
            env=env,
            output_files=output_files,
            input_files=input_files
        )

        self.assertEqual(result.return_code, 0)

    def test_return_code(self):
        dir_id = 'test_return_code' + str(random.randint(0, 999999))
        cmd = """python -c "exit(17)" """

        result = run_job_cmd(
            dir_id=dir_id,
            cmd=cmd
        )

        self.assertEqual(result.return_code, 17)

    def test_stdout(self):
        dir_id = 'test_stdout' + str(random.randint(0, 999999))
        cmd = """python -c "import sys; sys.stdout.write('some_text'); sys.stdout.flush()" """

        result = run_job_cmd(
            dir_id=dir_id,
            cmd=cmd
        )

        self.assertEqual(result.stdout, 'some_text')

    def test_stderr(self):
        dir_id = 'test_stderr' + str(random.randint(0, 999999))
        cmd = """python -c "import sys; sys.stderr.write('stderr_text'); sys.stderr.flush()" """

        result = run_job_cmd(
            dir_id=dir_id,
            cmd=cmd
        )

        self.assertEqual(result.stderr, 'stderr_text')

    def test_env(self):
        dir_id = 'test_env' + str(random.randint(0, 999999))

        cmd = """python -c "import sys; import os; sys.stdout.write(os.environ.get('env_test_0005')); sys.stdout.flush()" """
        env = {'env_test_0005': random_num_string()}

        result = run_job_cmd(
            dir_id=dir_id,
            cmd=cmd,
            env=env
        )

        self.assertEqual(result.stdout, random_num_string())

    def test_input_files(self):
        filename = os.path.join(BASE_TESTS_DIR, ''.join([str(random.randint(0, 9)) for _ in range(5)]))
        file_data = random_num_string(1000)

        with open(filename, 'wb') as fh:
            fh.write(file_data)

        dir_id = 'test_input_files' + str(random.randint(0, 999999))
        cmd = """python -c "import sys; fh = open('%s', 'rb'); sys.stdout.write(fh.read()); sys.stdout.flush(); fh.close()" """ % filename

        cache_client = CacheClient3()
        input_files = [cache_client.cache_file(filename)]

        result = run_job_cmd(
            dir_id=dir_id,
            cmd=cmd,
            input_files=input_files
        )

        self.assertEqual(result.stdout, file_data)

    def test_output_files(self):
        filename = os.path.join(BASE_TESTS_DIR, ''.join([str(random.randint(0, 9)) for _ in range(5)]))
        file_data = random_num_string(1000)

        dir_id = 'test_output_files' + str(random.randint(0, 999999))
        cmd = """python -c "fh = open('%s', 'wb'); fh.write('%s'); fh.close()" """ % (filename, file_data)

        output_files = [filename]

        result = run_job_cmd(
            dir_id=dir_id,
            cmd=cmd,
            output_files=output_files
        )

        cache_client = CacheClient3()

        for f in result.output_files:
            cache_client.get_file(f.sha256, f.path)

        self.assertTrue(os.path.exists(filename))
        with open(filename, 'rb') as fh:
            self.assertEqual(file_data, fh.read())

    def test_cancel_job(self):
        dir_id = 'test_cancel_job' + str(random.randint(0, 999999))
        cmd = """python -c "import time; time.sleep(600) """

        jobdata = job_submitter.get_linux_jobsubmission(
            dir_id=dir_id,
            cmd=cmd
        )

        job_id = job_submitter.submit_job(jobdata)

        r = job_submitter.cancel_job(job_id)

        self.assertTrue(r)

if __name__ == '__main__':
    unittest.main()