# coding: utf-8

# Copyright Luna Technology 2014
# Matthieu Riviere <mriviere@luna-technology.com>

import requests
import requests.exceptions
import logging
import time
import platform
from datetime import datetime
import hashlib
from sys import exit

from renderfarm_commons.protocols import jobsubmit_pb2


def _get_basic_jobsubmission(dir_id='default_job_id', cmd='', stdin='', env=None, output_files=None, input_files=None, workdir="."):
    jobsubmit = jobsubmit_pb2.JobSubmission()

    storage_info = jobsubmit.storage_info
    storage_info.type = 'FTP+redis'
    storage_info.ftp_host = '10.91.0.1'
    storage_info.ftp_root = 'files/'
    storage_info.redis_host = '10.91.0.1'

    jobsubmit.id = dir_id
    jobsubmit.stdin = stdin
    jobsubmit.cmd = cmd
    jobsubmit.workdir = workdir

    if input_files is None:
        input_files = []

    for f in input_files:
        f_data = jobsubmit.file.add()
        f_data.path = f['path']
        f_data.sha256 = f['sha256']

    if env is None:
        env = dict()

    for env_var in env:
        env_var_data = jobsubmit.env.add()
        env_var_data.key = env_var
        env_var_data.value = env[env_var]

    if output_files is None:
        output_files = []
    for f in output_files:
        jobsubmit.output_files.append(f)

    return jobsubmit


def get_windows_jobsubmission(**kwargs):
    jobsubmit = _get_basic_jobsubmission(**kwargs)
    jobsubmit.operating_system = jobsubmit_pb2.WINDOWS

    return jobsubmit


def get_linux_jobsubmission(**kwargs):
    jobsubmit = _get_basic_jobsubmission(**kwargs)
    jobsubmit.operating_system = jobsubmit_pb2.LINUX

    return jobsubmit


def get_jobsubmission(**kwargs):
    plt = platform.system()
    if plt == 'Windows':
        return get_windows_jobsubmission(**kwargs)
    elif plt == 'Linux':
        return get_linux_jobsubmission(**kwargs)
    else:
        raise RuntimeError('Unrecognized operating system: %s' % plt)


def submit_job(jobsubmit):
    headers = {'Content-type': 'application/octet-stream', 'Accept': 'application/octet-stream'}
    try:
        r = requests.post('http://10.91.0.1:15030/submit', data=jobsubmit.SerializeToString(), headers=headers)
    except requests.exceptions.RequestException:
        logging.exception('Error while submitting job')
        return None

    if r.status_code != 200:
        logging.warning("Could not submit job (server returned %d)" % r.status_code)
        return None

    response = jobsubmit_pb2.JobSubmissionResponse()
    response.ParseFromString(r.content)

    if response.result == jobsubmit_pb2.OK:
        logging.info("Job submitted with id %s" % response.id)
        return response.id
    else:
        return None


def get_job_status(job_id):
    req_data = jobsubmit_pb2.JobStatusRequest()
    req_data.id = job_id

    headers = {'Content-type': 'application/octet-stream', 'Accept': 'application/octet-stream'}
    r = requests.post('http://10.91.0.1:15030/jobstatus', data=req_data.SerializeToString(), headers=headers)

    if r.status_code != 200:
        logging.warning("Could not get job status (server returned %d)" % r.status_code)
        return None

    response = jobsubmit_pb2.JobStatusResponse()
    response.ParseFromString(r.content)

    if response.result == jobsubmit_pb2.OK:
        logging.info("Job status is %s" % response.job_status)
        return response.job_status
    else:
        logging.warn("Could not get job status")
        return None


def get_job_status_and_partial_results(job_id, next_stdout_part, partial_result_callback):
    req_data = jobsubmit_pb2.JobStatusRequest()
    req_data.id = job_id
    req_data.next_stdout_part = next_stdout_part

    headers = {'Content-type': 'application/octet-stream', 'Accept': 'application/octet-stream'}
    r = requests.post('http://10.91.0.1:15030/jobstatus', data=req_data.SerializeToString(), headers=headers)

    if r.status_code != 200:
        logging.warning("Could not get job status (server returned %d)" % r.status_code)
        return None, None

    response = jobsubmit_pb2.JobStatusResponse()
    response.ParseFromString(r.content)

    for output_part in response.job_result_data:
        if partial_result_callback is not None:
            partial_result_callback(output_part)

        next_stdout_part = output_part.order_id + 1

    if response.result == jobsubmit_pb2.OK:
        logging.info("Job status is %s" % response.job_status)

        return response.job_status, next_stdout_part
    else:
        logging.warn("Could not get job status")
        return None, None


def job_in_progress(job_id):
    req_data = jobsubmit_pb2.JobStatusRequest()
    req_data.id = job_id

    headers = {'Content-type': 'application/octet-stream', 'Accept': 'application/octet-stream'}
    r = requests.post('http://10.91.0.1:15030/jobstatus', data=req_data.SerializeToString(), headers=headers)

    if r.status_code != 200:
        logging.error("Could not get job status (server returned %d)" % r.status_code)
        return False

    response = jobsubmit_pb2.JobStatusResponse()
    response.ParseFromString(r.content)

    if response.result == jobsubmit_pb2.OK and (response.job_status == jobsubmit_pb2.IDLE or response.job_status == jobsubmit_pb2.RUNNING):
        return True
    else:
        return False


def wait_for_job_readiness(jid, max_failures=10, partial_result_callback=None):

    def cpuburn(duration=5):
        t1 = datetime.now()
        m = hashlib.sha512()
        while (datetime.now() - t1).seconds < duration:
            m.update("La-li-lu-le-lo")

    next_stdout_part = 0

    tries = 0
    failures = 0
    while True:
        try:
            status, next_stdout_part = get_job_status_and_partial_results(jid, next_stdout_part, partial_result_callback)
        except requests.exceptions.RequestException:
            logging.warning('Could not get job status. Server unreachable.', exc_info=True)
            failures += 1
        else:
            if status == jobsubmit_pb2.UNKNOWN:
                failures += 1
                logging.warn('Could not get job status')
            elif status == jobsubmit_pb2.IDLE or status == jobsubmit_pb2.RUNNING:
                pass
            elif status == jobsubmit_pb2.SUCCEEDED:
                logging.info('Job is finished. Moving on to fetch results.')
                break
            elif status == jobsubmit_pb2.CANCELED:
                logging.fatal('Job canceled. Exiting.')
                exit(-1)
            elif status == jobsubmit_pb2.FAILED:
                logging.fatal('Job failed. Exiting.')
                exit(-1)
            elif status is None:
                logging.info('No longer any status. Assuming job has finished.')
                break

        if failures >= max_failures:
            logging.fatal('Failed to get job status too many times. Exiting.')
            exit(-1)

        # Do 15 seconds of CPU-burn every two minutes, so that RoyalRender doesn't
        # consider the job freezed.
        tries += 1
        if tries % 8 == 0:
            cpuburn(15)

        time.sleep(15)


def wait_for_job_with_timeout(jid, timeout=200):
    max_tries = timeout
    tries = 0

    while tries < max_tries:
        if job_in_progress(jid):
            tries += 1
            time.sleep(1)
        else:
            return

    raise RuntimeError('Job didn\'t complete in time')


def get_results(job_id):
    req_data = jobsubmit_pb2.JobResultsRequest()
    req_data.id = job_id

    headers = {'Content-type': 'application/octet-stream', 'Accept': 'application/octet-stream'}
    try:
        r = requests.post('http://10.91.0.1:15030/getresults', data=req_data.SerializeToString(), headers=headers)
    except requests.exceptions.RequestException:
        logging.exception('Error while getting results')
        return None

    if r.status_code != 200:
        return None

    response = jobsubmit_pb2.JobResultsResponse()
    response.ParseFromString(r.content)

    if response.result == jobsubmit_pb2.OK:
        return response.data
    else:
        return None


def cancel_job(job_id):
    req_data = jobsubmit_pb2.JobCancelRequest()
    req_data.id = job_id

    headers = {'Content-type': 'application/octet-stream', 'Accept': 'application/octet-stream'}
    try:
        r = requests.post('http://10.91.0.1:15030/cancel', data=req_data.SerializeToString(), headers=headers)
    except requests.exceptions.RequestException:
        logging.exception('Error while cancelling job')
        return False

    if r.status_code != 200:
        return False

    response = jobsubmit_pb2.JobCancelResponse()
    response.ParseFromString(r.content)

    if response.result == jobsubmit_pb2.OK:
        return True
    else:
        return False


def run_windows_job_and_wait_for_results(**kwargs):
    timeout = kwargs.pop('timeout', 200)
    jobdata = get_windows_jobsubmission(**kwargs)
    job_id = submit_job(jobdata)
    wait_for_job_with_timeout(job_id, timeout=timeout)

    response_data = get_results(job_id)
    return response_data


def run_linux_job_and_wait_for_results(**kwargs):
    timeout = kwargs.pop('timeout', 200)
    jobdata = get_linux_jobsubmission(**kwargs)
    job_id = submit_job(jobdata)
    wait_for_job_with_timeout(job_id, timeout=timeout)

    response_data = get_results(job_id)
    return response_data
