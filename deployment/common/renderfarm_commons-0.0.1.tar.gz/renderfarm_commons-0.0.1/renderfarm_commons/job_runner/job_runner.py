# coding: utf-8

# Copyright Luna Technology 2014
# Matthieu Riviere <mriviere@luna-technology.com>


import locale
import subprocess
import os
import logging
import time

from luna_commons import list_tree, sha256sum, create_dir
from renderfarm_commons.protocols import jobsubmit_pb2
from renderfarm_commons.cache_client import filecache_client3


def sync_file_by_sha256(sha, target_path, storage_info):
    # FIXME: this method should signal failure

    cacheclient = filecache_client3.CacheClient3()
    cacheclient.get_file(sha, target_path)


def sync_files(files, storage_info):
    for f in files:
        print "Requested to sync file: %s (hash %s)" % (f.path, f.sha256)
        if sha256sum(f.path) == f.sha256:
            print "File already present. Skipping."
        else:
            sync_file_by_sha256(f.sha256, f.path, storage_info)


def get_output_files(output_files, storage_info):

    storage_info_dict = {
        'redis_host': storage_info.redis_host,
        'ftp_host': storage_info.ftp_host,
        'ftp_root': storage_info.ftp_root,
    }

    files_descr = []
    output_files2 = []

    # Expand directories and remove non-existing files
    for f in output_files:
        if not os.path.exists(f):
            print "Notice: Request to sync output file %s, but it doesn't exists" % f
            continue

        if os.path.isdir(f):
            output_files2 = output_files2 + list_tree(f)
            continue

        output_files2.append(f)

    # Upload all output files to the cache
    cache = filecache_client3.CacheClient3()
    for f in output_files2:
        while True:
            try:
                cache_info = cache.cache_file(f)
                break
            except Exception:
                # File already being uploaded ? Wait a bit and retry
                # FIXME: check that it's not a permanent error
                logging.exception('Could not upload file %s. Retrying in a while' % f)
                time.sleep(10)

        if cache_info is None:
            continue

        # Return the right metadata
        files_descr.append(cache_info)

    return files_descr


def get_environment(new_env, encoding):
    my_env = os.environ.copy()

    # Environment variables can't be unicode objects.
    # We have to manually encode them in the current shell encoding
    for env_var in new_env:
        my_env[env_var.key.encode(encoding)] = env_var.value.encode(encoding)

    logging.info("Environment is: %s" % my_env)

    return my_env


def do_run_job(job_input):
    """Does all the actual work to run a job.
    This takes as input a serialized jobsubmit_pb2.JobSubmission
    It return as output a serialized jobsubmit_pb2.JobResultsResponse"""
    jobsubmission = jobsubmit_pb2.JobSubmission()
    jobsubmission.ParseFromString(job_input)

    # Ensure the requested working directory exists
    create_dir(jobsubmission.workdir)

    # Get the files
    sync_files(jobsubmission.file, jobsubmission.storage_info)

    # Get the current session encoding
    encoding = locale.getpreferredencoding()

    # Update the local environment with the one passed in the job
    my_env_2 = get_environment(jobsubmission.env, encoding)

    # Run the desired command
    print "Command to run is: %s" % jobsubmission.cmd
    p = subprocess.Popen(
        jobsubmission.cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=True,
        env=my_env_2,
        cwd=jobsubmission.workdir,
    )
    out, err = p.communicate()

    # Create the response structure
    jobresponse = jobsubmit_pb2.JobResultsResponse()
    jobresponse.result = jobsubmit_pb2.OK

    jobresponse.data.return_code = p.returncode
    jobresponse.data.stdout = out.decode(encoding)
    jobresponse.data.stderr = err.decode(encoding)

    # Put the output files in the common storage and add their metadata to the return structure
    for f in get_output_files(jobsubmission.output_files, jobsubmission.storage_info):
        of = jobresponse.data.output_files.add()
        of.path = f['path']
        of.sha256 = f['sha256']

    # Serialize and return
    return jobresponse.SerializeToString()

