# coding: utf-8

# Copyright Luna Technology 2014
# Matthieu Riviere <mriviere@luna-technology.com>

"""Cluster_init is a simple boot system to run scripts, as a user, after the cluster VPN has gone up.
Put it in the user startup directory.

It will run all scripts you put in C:\Cluster_init"""

import platform
import logging
import time
from sys import exit

wait_for_openvpn_ip = None

if platform.system() == 'Windows':
    import wmi

    def wait_for_openvpn_ip_windows():
        cluster_vpn_ip = None
        while cluster_vpn_ip is None:
            c = wmi.WMI()
            for interface in c.Win32_NetworkAdapterConfiguration(IPEnabled=1):
                ip = interface.IPAddress[0]

                if ip.startswith('10.91'):
                    cluster_vpn_ip = ip

            time.sleep(2)

        return cluster_vpn_ip

    wait_for_openvpn_ip = wait_for_openvpn_ip_windows

elif platform.system() == 'Linux':
    import netifaces

    interface = 'tun6'

    def wait_for_openvpn_ip_linux():
        cluster_vpn_ip = None
        while cluster_vpn_ip is None:
            try:
                cluster_vpn_ip = netifaces.ifaddresses(interface)[netifaces.AF_INET][0]['addr']
            except Exception:
                pass

            time.sleep(2)

        return cluster_vpn_ip

    wait_for_openvpn_ip = wait_for_openvpn_ip_linux
else:
    raise RuntimeError('Unrecognized platform: %s' % platform.system())


def exec_on_vpn_ready(f):
    if wait_for_openvpn_ip is not None:
        cluster_ip = wait_for_openvpn_ip()
        f(cluster_ip)
    else:
        logging.error("Could not find any way to check for openvpn ip. Exiting.")
        exit(-1)
