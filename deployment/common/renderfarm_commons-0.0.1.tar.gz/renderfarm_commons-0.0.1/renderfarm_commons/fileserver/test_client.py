# coding: utf-8

# Copyright Luna Technology 2014
# Matthieu Riviere <mriviere@luna-technology.com>

"""Tests for the fileserver-agent-3 client (the SSH-enabled one).
To run these tests, you need to be on an SSH-reachable system. Generally a cluster master.
You need to have access to a client node with the fileserver-agent-3 running, and with the files
pointed by EXISTING_FILE and EXISTING_UNICODE_FILE available.

Fill in the fields:
THIS_HOST, THIS_USER, THIS_PASSWORD, THIS_HOSTKEY_FINGERPRINT, EXISTING_FILE_SHA, EXISTING_UNICODE_FILE_SHA
before running the tests"""

import unittest
import client
from luna_commons import create_dir, sha256sum
import shutil
import os
from nose.plugins.attrib import attr

BASE_TESTS_DIR = '/tmp/file_server_client_tests'
THIS_HOST = '54.54.54.54'
THIS_USER = 'uploader'
THIS_PASSWORD = 'YayUploader'
THIS_HOSTKEY_FINGERPRINT = 'aa:aa:aa:aa:aa:aa:aa:aa:aa:aa:aa:aa:aa:aa:aa:aa'

EXISTING_FILE = 'C:\\Luna\\test_data\\some_file_1'
EXISTING_UNICODE_FILE = 'C:\\Luna\\test_data\\Wéééé.exe'

EXISTING_FILE_SHA = '6515b6ddd2677cc9b6ea36b788205b1478bcd3b60d516e699d816ae3d39fa3af'
EXISTING_UNICODE_FILE_SHA = '5f6f62526e1b7651fc752b5229539782c3e5da5432e51bc9eafe9ccc57eed068'


@attr(cat='integration')
class FileServerClientTests(unittest.TestCase):

    def setUp(self):
        create_dir(BASE_TESTS_DIR)

    def tearDown(self):
        try:
            shutil.rmtree(BASE_TESTS_DIR)
        except Exception:
            pass

    def get_correct_client(self):
        c = client.FileServerClient(
            THIS_HOST,
            THIS_USER,
            THIS_PASSWORD,
            THIS_HOSTKEY_FINGERPRINT
        )
        return c

    def test_fetch_file(self):
        local_path = os.path.join(BASE_TESTS_DIR, 'real_file')

        c = self.get_correct_client()
        ret = c.get_file(EXISTING_FILE, local_path)

        self.assertEqual(ret, True)
        self.assertEqual(sha256sum(local_path), EXISTING_FILE_SHA)

    def test_fetch_absent_file(self):
        file_path = 'C:\\Luna\\absentpath'
        local_path = os.path.join(BASE_TESTS_DIR, 'real_file')

        c = self.get_correct_client()
        ret = c.get_file(file_path, local_path)

        self.assertEqual(ret, False)
        self.assertFalse(os.path.exists(local_path))

    def test_fetch_with_bad_fingerprint(self):
        """Tests that the server actually processes our hostkey fingerprint.
        (this probably belongs in the server tests, but it doesn't hurt to test it here)"""
        local_path = os.path.join(BASE_TESTS_DIR, 'real_file')

        c = self.get_correct_client()
        c.my_host_key_fingerprint = 'woot:pwned'
        ret = c.get_file(EXISTING_FILE, local_path)

        self.assertEqual(ret, False)
        self.assertFalse(os.path.exists(local_path))

    def test_fetch_directory(self):
        """Tests that we don't break everything if we send in a directory"""
        local_path = os.path.join(BASE_TESTS_DIR, 'real_file')

        c = self.get_correct_client()
        ret = c.get_file(os.path.dirname(EXISTING_FILE), local_path)

        self.assertEqual(ret, False)
        self.assertFalse(os.path.exists(local_path))

    def test_fetch_unicode_filename(self):
        local_path = os.path.join(BASE_TESTS_DIR, 'real_file')

        c = self.get_correct_client()
        ret = c.get_file(EXISTING_UNICODE_FILE, local_path)

        self.assertEqual(ret, True)
        self.assertEqual(sha256sum(local_path), EXISTING_UNICODE_FILE_SHA)

    def test_fetch_to_unicode_filename(self):
        local_path = os.path.join(BASE_TESTS_DIR, 'wééélol')

        c = self.get_correct_client()
        ret = c.get_file(EXISTING_FILE, local_path)

        self.assertEqual(ret, True)
        self.assertEqual(sha256sum(local_path), EXISTING_FILE_SHA)

    def test_fetch_to_nonexistent_directory(self):
        local_path = os.path.join(BASE_TESTS_DIR, 'tu/peux/pas/test')

        c = self.get_correct_client()
        ret = c.get_file(EXISTING_FILE, local_path)

        self.assertEqual(ret, True)
        self.assertEqual(sha256sum(local_path), EXISTING_FILE_SHA)

if __name__ == '__main__':
    unittest.main()