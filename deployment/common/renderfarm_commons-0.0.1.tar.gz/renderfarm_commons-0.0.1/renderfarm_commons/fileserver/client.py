# coding: utf-8

# Copyright Luna Technology 2014
# Matthieu Riviere <mriviere@luna-technology.com>

"""

Note: SSH fingerprint can be obtained by doing:
ssh-keygen -lf /etc/ssh/ssh_host_rsa_key
"""

import requests
import requests.exceptions
import json
import logging
import os
import shutil
from tempfile import NamedTemporaryFile
from luna_commons import create_dir


class FileServerClient(object):

    def __init__(self, my_host, my_username, my_password, my_host_key_fingerprint, remote_host='10.91.1.1', remote_port=15024):
        self.my_host = my_host
        self.my_username = my_username
        self.my_password = my_password
        self.my_host_key_fingerprint = my_host_key_fingerprint
        self.remote_host = remote_host
        self.remote_port = remote_port

    def get_file(self, distant_path, local_path):

        fd = self.get_file_as_fd(distant_path)

        if fd is not None:
            create_dir(os.path.dirname(local_path))
            with open(local_path, 'wb') as dest_f:
                shutil.copyfileobj(fd, dest_f)
            return True
        else:
            return False

    def get_file_as_fd(self, distant_path):
        """Gets a file with the multiple-secondary-ssh technique.
        Returns true if the download succeeded, false otherwise.
        The number of connections that will be made is server-defined."""

        # Get a temporary file name to use as a basepath. We use a suffix, so that we don't clash
        # between temporary files when we append numbers to this base path.
        tmp = NamedTemporaryFile(suffix='_lunacustomssh', delete=True)

        # Parameters on where to send the file.
        data = {
            'path': distant_path,
            'upload_basepath': tmp.name,
            'host': self.my_host,
            'username': self.my_username,
            'password': self.my_password,
            'ssh_fingerprint': self.my_host_key_fingerprint.translate(None, ':')
        }

        # Make the request to initiate the connection
        try:
            r = requests.post('http://%s:%d/ssh_file' % (self.remote_host, self.remote_port,), data=data)
        except requests.exceptions.RequestException:
            logging.exception('Unable to connect to file server.')
            return None
        else:
            if r.status_code == 200:
                dataparts = json.loads(r.content)

                if dataparts['status'] == 'Ko':
                    logging.error('Distant server returned an error: %s' % dataparts['error'])
                    return None

                fetch_succeeded = True

                dest_f = NamedTemporaryFile()

                for part in dataparts['parts']:
                    # SHA-computation too expensive. Disable for now.
                    # Check the part SHA-sum
                    # reference_sha = part['sha']
                    # computed_sha = sha256sum(part['path'])
                    # if reference_sha != computed_sha:
                    #     logging.error('SHA sum mismatch on file. Expected %s but got %s' % (reference_sha, computed_sha,))
                    #     return False

                    # It *is* possible the server returns ok when it hasn't in fact sent the files.
                    # It happens for example when the server has ssh-connectivity issues
                    if not os.path.exists(part['path']):
                        logging.error('Server didn\'t actually send file %s.' % part['path'])
                        fetch_succeeded = False
                        break

                    with open(part['path'], 'rb') as source_f:
                        # Could be memory-consuming. But it's okay, we have tons of memory.
                        dest_f.write(source_f.read())

                # No point in check the SHA/size if we know things failed already
                if fetch_succeeded:
                    # Don't do that. Too slow to compute on the other side
                    # reference_sha_final = dataparts['sha']
                    # computed_sha_final = sha256sum_fd(dest_f)
                    #
                    # if reference_sha_final != computed_sha_final:
                    #     logging.error('SHA sum mismatch on final file. Expected %s but got %s' % (reference_sha_final, computed_sha_final,))
                    #     fetch_succeeded = False

                    reference_size_final = dataparts['size']
                    dest_f.seek(0, 2)
                    computed_size_final = dest_f.tell()
                    dest_f.seek(0)
                    if reference_size_final != computed_size_final:
                        logging.error('Size mismatch on final file. Expected %d but got %d' % (reference_size_final, computed_size_final,))
                        fetch_succeeded = False

                # Cleanup the temporary files
                for part in dataparts['parts']:
                    if os.path.exists(part['path']):
                        os.remove(part['path'])

                if fetch_succeeded:
                    return dest_f
                else:
                    return None

            else:
                logging.error('HTTP request return code %d' % r.status_code)
                return None
